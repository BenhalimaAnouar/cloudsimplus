/*
 * Copyright 2015 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package com.google.googlejavaformat.java;

import static com.google.common.collect.ImmutableList.toImmutableList;
import static java.util.Locale.ENGLISH;

import com.google.common.base.CharMatcher;
import com.google.common.base.Splitter;
import com.google.common.collect.ImmutableList;
import com.google.googlejavaformat.FormatterDiagnostic;
import java.util.List;
import java.util.regex.Pattern;
import javax.tools.Diagnostic;
import javax.tools.JavaFileObject;

/** Checked exception class for formatter errors. */
public final class FormatterException extends Exception {

  private final ImmutableList<FormatterDiagnostic> diagnostics;

  public FormatterException(String message) {
    this(FormatterDiagnostic.create(message));
  }

  public FormatterException(FormatterDiagnostic diagnostic) {
    this(ImmutableList.of(diagnostic));
  }

  public FormatterException(Iterable<FormatterDiagnostic> diagnostics) {
    super(diagnostics.iterator().next().toString());
    this.diagnostics = ImmutableList.copyOf(diagnostics);
  }

  public List<FormatterDiagnostic> diagnostics() {
    return diagnostics;
  }

  public static FormatterException fromJavacDiagnostics(
      List<Diagnostic<? extends JavaFileObject>> diagnostics) {
    return new FormatterException(
        diagnostics.stream()
            .map(FormatterException::toFormatterDiagnostic)
            .collect(toImmutableList()));
  }

  private static FormatterDiagnostic toFormatterDiagnostic(Diagnostic<?> input) {
    return FormatterDiagnostic.create(
        (int) input.getLineNumber(), (int) input.getColumnNumber(), input.getMessage(ENGLISH));
  }

  public String formatDiagnostics(String path, String input) {
    List<String> lines = Splitter.on(NEWLINE_PATTERN).splitToList(input);
    StringBuilder sb = new StringBuilder();
    for (FormatterDiagnostic diagnostic : diagnostics()) {
      sb.append(path).append(":").append(diagnostic).append(System.lineSeparator());
      int line = diagnostic.line();
      int column = diagnostic.column();
      if (line != -1 && column != -1) {
        sb.append(CharMatcher.breakingWhitespace().trimTrailingFrom(lines.get(line - 1)))
            .append(System.lineSeparator());
        sb.append(" ".repeat(column - 1)).append('^').append(System.lineSeparator());
      }
    }
    return sb.toString();
  }

  private static final Pattern NEWLINE_PATTERN = Pattern.compile("\\R");
}
